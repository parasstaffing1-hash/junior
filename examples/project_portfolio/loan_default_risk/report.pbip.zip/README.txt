Generated Power BI project. Extract this ZIP, enable Power BI Desktop's Power BI Project (PBIP) preview feature, then open the .pbip file.
